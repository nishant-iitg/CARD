Usage:

1. cd TightClusteringSenseDetection/
2. Generate CARD independant output:
java -cp ./bin MetaMapWrapper.SenseDisambiguationText input_dir card_output_dir

Where, input_dir contains all the input txt files. The CARD independant result will be generated under 'card_output_dir'.


2. Generate CARD output as MetaMap Wrapper:

java -cp ./bin MetaMapWrapper.SenseDisambiguationMetaMap metamap_input_dir card_output_dir 

Where, metamap_input_dir contains the metamap output files with option "-I". CARD system will read the metamap output file, do sense disambiguation and finally output the modified results to 'card_output_dir'.

